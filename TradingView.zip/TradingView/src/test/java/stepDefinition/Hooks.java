package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Hooks {
	
	   
	      @Before 
	      public void setup() { 
	    	  
	         
	      } 
	      @After 
	      public void teardown() { 
	  
	      } 
	      @BeforeStep 
	      public void beforeSteps() { 
	            System.out.println("Before Steps"); 
	      } 
	       @AfterStep 
	       public void afterSteps() { 
	            System.out.println("After Steps"); 
	       } 
	       
	       

}
