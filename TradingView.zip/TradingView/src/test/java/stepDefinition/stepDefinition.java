package stepDefinition;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import io.github.bonigarcia.wdm.WebDriverManager;

public class stepDefinition {
	
	WebDriver driver;
	@Given("I navgiate to {string}")
	public void i_navgiate_to(String url) throws InterruptedException {
		WebDriverManager.chromedriver().setup(); 
  	    driver  = new ChromeDriver(); 
        driver.manage().window().maximize(); 
        driver.get(url);
        
	}

	@Given("Signin with {string} {string}")
	public void signin_with_and_success(String username, String password) {
		
		driver.findElement(By.cssSelector(".tv-header__user-menu-button > svg")).click();
        driver.findElement(By.xpath("//span[contains(text(),'Sign in')]")).click();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Email')]"))); 
        driver.findElement(By.xpath("//span[contains(text(),'Email')]")).click();
        
        
       
        driver.findElement(By.name("username")).sendKeys(username);
        driver.findElement(By.name("password")).sendKeys(password);
        
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(60));
        wait1.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//button[contains(@id,'email-signin__submit-button')]"))));  
        driver.findElement(By.xpath("//button[contains(@id,'email-signin__submit-button')]")).click();
        
        driver.findElement(By.cssSelector(".footer-ZXbT4bae")).click();
        driver.findElement(By.cssSelector(".tv-dialog__modal-container")).click();
        driver.findElement(By.cssSelector(".tv-dialog__modal-body")).click();
        
	}

	@Given("select {string}")
	public void select(String string) throws InterruptedException {

        WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(60));
        wait2.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//a[contains(@href,'rates-asia')]")))); 
        driver.findElement(By.xpath("//a[contains(@href,'rates-asia')]")).click();
	    
	}

	@When("I perform search currency pair {string}")
	public void i_perform_search_currency_pair(String string) throws InterruptedException {
		driver.findElement(By.xpath("//button[contains(@aria-label,'Search')]")).click();
        driver.findElement(By.xpath("//input[@name='query']")).sendKeys("FX: GBPJPY");
        Actions actions = new Actions(driver);
        WebElement element =driver.findElement(By.xpath("//div[@title='FXCM']"));
        actions.moveToElement(element).build().perform();
        driver.findElement(By.xpath("//button[contains(.,'See overview')]")).click();
	}

	@Then("Verify that you are on correct page")
	public void verify_that_you_are_on_correct_page() {
        
        Assert.assertTrue(driver.getTitle().contains("GBP JPY Chart"));
	}
	

}
